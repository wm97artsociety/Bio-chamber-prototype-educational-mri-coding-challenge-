# GUI for visual rebirth feedback
