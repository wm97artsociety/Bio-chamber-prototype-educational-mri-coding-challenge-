# Triggers MRI rebirth sequence via Pulseq
