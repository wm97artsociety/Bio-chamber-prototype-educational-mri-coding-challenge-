# Connects to MRI or simulation backend
