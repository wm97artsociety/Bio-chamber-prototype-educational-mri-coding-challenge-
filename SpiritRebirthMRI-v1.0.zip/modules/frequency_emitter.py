# Emits 777 Hz tone
