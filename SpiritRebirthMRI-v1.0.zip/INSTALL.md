## Installation Instructions
Install Python 3.10+
Run: pip install -r requirements.txt
