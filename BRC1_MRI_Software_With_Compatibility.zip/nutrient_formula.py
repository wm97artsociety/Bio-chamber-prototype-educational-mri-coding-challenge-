def manage_nutrients():
    print("Monitoring nutrient levels...")
    print("Administering Canna+ formula where required.")
